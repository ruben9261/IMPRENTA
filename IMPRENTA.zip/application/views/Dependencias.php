<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<link rel="stylesheet" type="text/css" href="../public/alertifyjs/css/alertify.css">
<link rel="stylesheet" type="text/css" href="../public/alertifyjs/css/themes/default.css">
<link rel="stylesheet" type="text/css" href="../public/bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="../public/select2/css/select2.css">
<link rel="stylesheet" type="text/css" href="../public/css/menu.css">

<script src="../public/jquery/jquery-3.2.1.min.js"></script>
<script src="../librerias/alertifyjs/alertify.js"></script>
<script src="../librerias/bootstrap/js/bootstrap.js"></script>
<script type="../librerias/select2/js/select2.js"></script>
<script src="../js/funciones.js"></script>